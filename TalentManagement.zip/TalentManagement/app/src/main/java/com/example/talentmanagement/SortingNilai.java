package com.example.talentmanagement;

public class SortingNilai {
    String tvDivisi, tvPersentase;

    public SortingNilai(String Divisi, int round) {
        return;

    }

    public String getTvDivisi() {
        return tvDivisi;
    }

    public String getTvPersentase() {
        return tvPersentase;
    }
}
